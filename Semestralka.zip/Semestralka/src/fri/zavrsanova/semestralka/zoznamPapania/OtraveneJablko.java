/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fri.zavrsanova.semestralka.zoznamPapania;

import fri.zavrsanova.semestralka.hrac.Hrac;
import javax.swing.JOptionPane;

/**
 *
 * @author Admin
 */
public class OtraveneJablko extends Papanie {

    private int skore = 3;
            
    public OtraveneJablko(int suradnicaX, int suradnicaY) {
        super("otraveneJablko", "red", 22, suradnicaX, suradnicaY);
    }

    @Override
    public void zjedz(Hrac hrac) {
        hrac.znizZivot();
        hrac.znizSkore(skore);
        JOptionPane.showMessageDialog(null, "Zjedol si otrávené jablko! \n Buď opatrnejší, \n pretože máš už len " + hrac.getPocetZivotov() + " zivoty");
    }

    

}
