/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fri.zavrsanova.semestralka.zoznamPapania;

import fri.zavrsanova.semestralka.hrac.Hrac;
import javax.swing.JOptionPane;

/**
 *
 * @author Admin
 */
public class HroznovyCukor extends Papanie {

    private final int skore = 10;
    
    public HroznovyCukor(int suradnicaX, int suradnicaY) {
        super("hroznovyCukor", "blue",15 , suradnicaX, suradnicaY);
    }

    @Override
    public void zjedz(Hrac hrac) {
        hrac.pridajZivot();
        JOptionPane.showMessageDialog(null, "Hroznový cukor ti pridal život! \n Máš " + hrac.getPocetZivotov() + "zivotov");
        hrac.pridajSkore(skore);
        
    }

    
}
