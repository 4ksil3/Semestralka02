/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fri.zavrsanova.semestralka.zoznamPapania;

import fri.zavrsanova.semestralka.hrac.Hrac;
/**
 *
 * @author Admin
 */
public class Plesen extends Papanie {

    private final int zmenVelkost = -2;
    private int skore = 1;

    public Plesen(int suradnicaX, int suradnicaY) {
        super("plesen","green", 35, suradnicaX, suradnicaY);
    }

    @Override
    public void zjedz(Hrac hrac) {
        hrac.zmenVelkost(this.zmenVelkost);
        hrac.znizSkore(skore);
    }

}
