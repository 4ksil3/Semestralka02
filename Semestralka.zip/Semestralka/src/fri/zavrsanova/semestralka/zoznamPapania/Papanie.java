/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fri.zavrsanova.semestralka.zoznamPapania;

import fri.zavrsanova.semestralka.grafika.Kruh;
import fri.zavrsanova.semestralka.hrac.Hrac;

/**
 * Trieda papanie urciena na dedenie
 * @author zavrsanova
 */
public abstract class Papanie {

    private Kruh papanie;
    private String nazov;
    private String farba;
    private int suradnicaX;
    private int suradnicaY;
    private int stredX;
    private int stredY;
    private int priemer;

    public Papanie(String nazov, String farba, int priemer, int suradnicaX, int suradnicaY) {
        this.nazov = nazov;
        this.farba = farba;
        this.papanie = new Kruh();     
        this.suradnicaX = suradnicaX;
        this.suradnicaY = suradnicaY;
        this.papanie.posunVodorovne(this.suradnicaX - 20);
        this.papanie.posunZvisle(this.suradnicaY - 60);
        this.priemer = priemer;
        this.papanie.zmenFarbu(farba);
        this.papanie.zmenPriemer(this.priemer);
        this.stredX = this.priemer / 2 + this.suradnicaX;
        this.stredY = this.priemer / 2 + this.suradnicaY;
        this.papanie.zobraz();
    }
    
    /**
     *
     */
    public abstract void zjedz(Hrac hrac);

    public void nastavStred() {
        this.stredX = this.getPriemer() / 2 + this.getSuradnicaX();
        this.stredY = this.getPriemer() / 2 + this.getSuradnicaY();
    }

    public int getPriemer() {
        return this.priemer;
    }

    public int getSredX() {
        return this.stredX;
    }

    public int getSredY() {
        return this.stredY;
    }

    public String getNazov() {
        return this.nazov;
    }
    
    public int getSuradnicaX() {
        return this.suradnicaX;
    }

    public int getSuradnicaY() {
        return this.suradnicaY;
    }
    
    public void skry() { 
        this.papanie.skry();
    }

    
}