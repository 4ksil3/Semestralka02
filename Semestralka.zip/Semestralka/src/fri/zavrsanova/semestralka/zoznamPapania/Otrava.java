/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fri.zavrsanova.semestralka.zoznamPapania;

import fri.zavrsanova.semestralka.hrac.Hrac;

/**
 *
 * @author Admin
 */
public class Otrava extends Papanie {
    
    public Otrava(int suradnicaX, int suradnicaY) {
        super("otrava", "black", 50, suradnicaX, suradnicaY);
    }

    @Override
    public void zjedz(Hrac hrac) {
        hrac.zomrel();
    }  
    
    
    
}