/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fri.zavrsanova.semestralka.zoznamPapania;

import fri.zavrsanova.semestralka.hrac.Hrac;

/**
 *
 * @author Admin
 */
public class Olej extends Papanie {

    public Olej(int suradnicaX, int suradnicaY) {
        super("olej", "yellow", 25, suradnicaX, suradnicaY);
    }

    @Override
   public void zjedz(Hrac hrac) {
       hrac.otocSmer();
    }

}
