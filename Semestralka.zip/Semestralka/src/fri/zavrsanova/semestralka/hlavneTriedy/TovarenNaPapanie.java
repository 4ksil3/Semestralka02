/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fri.zavrsanova.semestralka.hlavneTriedy;

import fri.zavrsanova.semestralka.zoznamPapania.Plesen;
import fri.zavrsanova.semestralka.zoznamPapania.Papanie;
import fri.zavrsanova.semestralka.zoznamPapania.Otrava;
import fri.zavrsanova.semestralka.zoznamPapania.Olej;
import fri.zavrsanova.semestralka.zoznamPapania.Jablcko;
import java.awt.Point;
import java.util.ArrayList;
import java.util.Random;
import fri.zavrsanova.semestralka.mapa.Mapa;
import fri.zavrsanova.semestralka.zoznamPapania.HroznovyCukor;
import fri.zavrsanova.semestralka.zoznamPapania.OtraveneJablko;
import fri.zavrsanova.semestralka.zoznamPapania.Sumienka;

/**
 * Trieda TovarenNaPapanie ma na starosti vytvaranie roznych papani v zavislosti
 * od pravdepodobnosti a ulozenie vytvoreneho papania do mapy. Na zaciatku hry
 * vytvori zaciatocny herny plan.
 */
public final class TovarenNaPapanie {

    private final ArrayList<String> moznosti;
    private final Mapa mapa;
    private final int sirkaPlatna = 700;
    private final int vyskaPlatna = 700;

    public TovarenNaPapanie(Mapa mapa) {
        this.mapa = mapa;
        this.moznosti = new ArrayList<>();
        this.moznostiPapania();
    }

    /**
     * Obsahuje arraylist so vsetkymi typmi papania.
     */
    public void moznostiPapania() {
        this.moznosti.add("plesen");
        this.moznosti.add("jablko");
        this.moznosti.add("olej");
        this.moznosti.add("otrava");
        this.moznosti.add("sumienka");
        this.moznosti.add("otraveneJablko");
        this.moznosti.add("hroznovyCukor");
    }

    /**
     * Vygeneruje nahodne cislo od 0 po 1, na zaklade, ktoreho sa podla
     * pravdepodobnosti vyberie dane papanie.
     *
     * @return String nazov vygenerovaneho papania
     */
    public String vygenerujNazovPapania() {
        Random random = new Random();
        double ktore = random.nextDouble();
        if (ktore <= 0.40) {
            return this.moznosti.get(1);//jablko
        } else if (ktore <= 0.52) {
            return this.moznosti.get(5);//otravene jablko
        } else if (ktore <= 0.72) {
            return this.moznosti.get(0);//plesen
        } else if (ktore <= 0.78) {
            return this.moznosti.get(4);//sumienka
        } else if (ktore <= 0.90) {
            return this.moznosti.get(2);//olej
        } else if (ktore <= 0.95) {
            return this.moznosti.get(3);//otrava
        } else {
            return this.moznosti.get(6);
        }
    }

    /**
     * Vygeneruje nahodnu poziciu, na ktorej sa ma vytvorit instancia noveho
     * papania.
     *
     * @return x a y suradnice
     */
    public Point vygenerujNahodnuPozicia() {
        Random random = new Random();
        int x = random.nextInt(this.sirkaPlatna);
        int y = random.nextInt(this.vyskaPlatna);
        return new Point(x, y);
    }

    /**
     * Podla parametra nazovPapania sa rozhode o tom, ktoreho papania sa vytvori
     * instancia
     *
     * @param nazovPapania
     * @return vrati instanciu papania
     */
    public Papanie vytvorPapanie(String nazovPapania) {
        Point suradnice = this.vygenerujNahodnuPozicia();
        switch (nazovPapania) {
            case "jablko":
                return new Jablcko((int) suradnice.getX(), (int) suradnice.getY());
            case "plesen":
                return new Plesen((int) suradnice.getX(), (int) suradnice.getY());
            case "olej":
                return new Olej((int) suradnice.getX(), (int) suradnice.getY());
            case "otrava":
                return new Otrava((int) suradnice.getX(), (int) suradnice.getY());
            case "sumienka":
                return new Sumienka((int) suradnice.getX(), (int) suradnice.getY());
            case "otraveneJablko":
                return new OtraveneJablko((int) suradnice.getX(), (int) suradnice.getY());
            case "hroznovyCukor":
                return new HroznovyCukor((int) suradnice.getX(), (int) suradnice.getY());
            default:
                return null;
        }

//        Papanie papanie;
//        Point suradnice = this.vygenerujNahodnuPozicia();
//        papanie = new Jablcko((int) suradnice.getX(), (int) suradnice.getY());
//        papanie.nastavStred();
//        this.mapa.pridajDoMapy(papanie);
    }

    /**
     * Prida do mapy instanciu papania.
     */
    public void vytvorInstanciuPapania() {
        this.mapa.pridajDoMapy(this.vytvorPapanie(this.vygenerujNazovPapania()));
    }

    /**
     * Vytvorí sa zaciatocny herny plan.
     */
    public void vytvorZaciatok() {
        int pom = 0;
        while (pom < 12) {
            this.vytvorInstanciuPapania();
            pom++;
        }
    }

}
