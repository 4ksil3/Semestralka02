/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fri.zavrsanova.semestralka.grafika;

import fri.zavrsanova.semestralka.mapa.Smer;
import fri.zavrsanova.semestralka.zoznamPapania.Papanie;

/**
 * Trieda Lopta predstavuje zakladne nastavenia hraca. Nastavi zaciatocne
 * hodnoty pre hraca.
 *
 */
public class Lopta {

    private final Kruh lopticka;
    private int suradnicaX;
    private int suradnicaY;
    private int stredLoptyX;
    private int stredLoptyY;
    private int priemer;
    private final int sirkaPlatna = 700;
    private final int vyskaPlatne = 700;

    public Lopta() {
        this.lopticka = new Kruh();
        this.lopticka.posunVodorovne(330);
        this.suradnicaX = 350;
        this.lopticka.posunZvisle(290);
        this.suradnicaY = 350;
        this.priemer = 30;
        this.nastavStred();
    }

    /**
     * Zobrazi loptu.
     */
    public void zobrazLoptu() {
        this.lopticka.zobraz();
    }

    /**
     * Skryje loptu.
     */
    public void skryLoptu() {
        this.lopticka.skry();
    }
    
    /**
     * Zmeni farbu lopticky.
     */
    public void zmenFarbu(String farba) {
        this.lopticka.zmenFarbu(farba);
    }

    /**
     * Vrati suradnicu X.
     *
     * @return int suradnica X
     */
    public int getSuradnicaX() {
        return this.suradnicaX;
    }

    /**
     * Vrati suradnicu Y.
     *
     * @return int suradnica Y
     */
    public int getSuradnicaY() {
        return this.suradnicaY;
    }

    /**
     * Vrati priemer lopty.
     *
     * @return int priemer
     */
    public int getPriemer() {
        return this.priemer;
    }

    /**
     * Vrati stred X lopty.
     *
     * @return int stredX
     */
    public int getStredLoptyX() {
        return this.stredLoptyX;
    }

    /**
     * Vrati stred Y lopty.
     *
     * @return int stredY
     */
    public int getStredLoptyY() {
        return this.stredLoptyY;
    }

    /**
     * Vrati sirku platna.
     *
     * @return int sirka platna
     */
    public int getSirkaPlatna() {
        return sirkaPlatna;
    }

    /**
     * Vrati vysku platna.
     *
     * @return int vysku platna
     */
    public int getVyskaPlatne() {
        return vyskaPlatne;
    }

    /**
     * Nastaví stredove suradnice lopty.
     *
     */
    public void nastavStred() {
        this.stredLoptyX = this.getPriemer() / 2 + this.getSuradnicaX();
        this.stredLoptyY = this.getPriemer() / 2 + this.getSuradnicaY();
    }

    /**
     * Zmeni priemer lopty o cislo zadane ako parameter.
     *
     * @param okolko cislo o kolko sa zvacsi priemer
     */
    public void zmenVelkost(int okolko) {
        this.lopticka.zmenPriemer(this.priemer + okolko);
        this.priemer += okolko;
        this.nastavStred();
    }

//    public Smer posunDole() {
//        this.lopticka.posunZvisle(this.rychlostPohybu);
//        this.suradnicaY += this.rychlostPohybu;
//        this.nastavStred();
//        return Smer.DOLE;
//    }
//
//    public Smer posunHore() {
//        this.lopticka.posunZvisle(-this.rychlostPohybu);
//        this.suradnicaY -= this.rychlostPohybu;
//        this.nastavStred();
//        return Smer.HORE;
//    }
//
//    public Smer posunVlavo() {
//        this.lopticka.posunVodorovne(-this.rychlostPohybu);
//        this.suradnicaX -= this.rychlostPohybu;
//        this.nastavStred();
//        return Smer.VLAVO;
//    }
//
//    public Smer posunVpravo() {
//        this.lopticka.posunVodorovne(this.rychlostPohybu);
//        this.suradnicaX += this.rychlostPohybu;
//        this.nastavStred();
//        return Smer.VPRAVO;
//    }
    /**
     * Zabezpecuje zmenu smeru lopty na zaklade parametra smer a prechod cez
     * hranice platna.
     *
     * @param smer urcuje do akeho smeru sa ma lopta pohnut
     */
    public void pohyb(Smer smer) {
        this.lopticka.skry();
        switch (smer) {
            case DOLE:
                if (this.suradnicaY == 700) {
                    this.lopticka.skry();
                    this.lopticka.posunZvisle(-700);
                    this.suradnicaY = 0;
                    this.lopticka.zobraz();
                } else {
                    this.lopticka.posunZvisle(10);
                    this.suradnicaY += 10;
                }
                break;
            case HORE:
                if (this.suradnicaY <= 10) {
                    this.lopticka.skry();
                    this.lopticka.posunZvisle(700);
                    this.suradnicaY = 700;
                    this.lopticka.zobraz();
                } else {
                    this.lopticka.posunZvisle(-10);
                    this.suradnicaY -= 10;
                }
                break;
            case VLAVO:
                if (this.suradnicaX == 0) {
                    this.lopticka.skry();
                    this.lopticka.posunVodorovne(700);
                    this.suradnicaX = 700;
                    this.lopticka.zobraz();
                } else {
                    this.lopticka.posunVodorovne(-10);
                    this.suradnicaX -= 10;
                }
                break;
            case VPRAVO:
                if (this.suradnicaX == 700) {
                    this.lopticka.skry();
                    this.lopticka.posunVodorovne(-700);
                    this.suradnicaX = 0;
                    this.lopticka.zobraz();
                } else {
                    this.lopticka.posunVodorovne(10);
                    this.suradnicaX += 10;
                }
                break;
        }
        this.nastavStred();
        this.lopticka.zobraz();
    }

    /**
     * Kontroluje kolizie lopty s papanim, ktore dostane v podobe parametra.
     *
     * @param papanie
     * @return boolean vrati true ak doslo ku kolizii a false ak nedoslo ku
     * kolizii
     */
    public boolean kolizie(Papanie papanie) {
        if (Math.abs(this.stredLoptyX - papanie.getSredX()) < this.priemer / 2 + papanie.getPriemer() / 2) {
            if (Math.abs(this.stredLoptyY - papanie.getSredY()) < this.priemer / 2 + papanie.getPriemer() / 2) {
                return true;
            }
        }
        return false;
    }
    
    /**
     * Zmeni suradnicu X lopty a posunie ju na spravne miesto.
     * @param cislo o ake cislo sa ma zmenit suradnica X
     */
    public void zmenSuradniceX(int cislo) {
        int pom = this.suradnicaX;
        this.suradnicaX += cislo - pom;
        this.lopticka.posunVodorovne(cislo - pom);

    }

    /**
     * Zmeni suradnicu Y lopty a posunie ju na spravne miesto.
     * @param cislo o ake cislo sa ma zmenit suradnica Y
     */
    public void zmenSuradniceY(int cislo) {
        int pom = this.suradnicaY;
        this.suradnicaY += cislo - pom;
        this.lopticka.posunZvisle(cislo - pom);
    }
    
    
}
