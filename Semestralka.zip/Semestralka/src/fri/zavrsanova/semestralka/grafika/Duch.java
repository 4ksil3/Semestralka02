/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fri.zavrsanova.semestralka.grafika;

import fri.zavrsanova.semestralka.hrac.Hrac;
import fri.zavrsanova.semestralka.mapa.Smer;
import fri.zavrsanova.semestralka.zoznamPapania.Papanie;
import java.util.Random;

/**
 *
 * @author Admin
 */
public class Duch {

    private Lopta duch;
    private int cislo;

    public Duch() {
        this.duch = new Lopta();
        this.cislo = 0;
        this.duch.zmenFarbu("black");
        this.duch.zobrazLoptu();
        
    }

    public void pohyb() {
        switch (this.cislo) {
            case 0:
                this.duch.pohyb(Smer.HORE);
                break;
            case 1:
                this.duch.pohyb(Smer.VPRAVO);
                break;
            case 2:
                this.duch.pohyb(Smer.DOLE);
                break;
            case 3:
                this.duch.pohyb(Smer.VLAVO);
                break;
        }
    }
    
    public void nastavSmer() {
        Random random = new Random();
        this.cislo = random.nextInt(4);
    }
    
   public boolean kolizie(Hrac hrac) {
        if (Math.abs(this.duch.getStredLoptyX() - hrac.getStredX()) < this.duch.getPriemer() / 2 + hrac.getPriemer() / 2) {
            if (Math.abs(this.duch.getStredLoptyY() - hrac.getStredY()) < this.duch.getPriemer() / 2 + hrac.getPriemer() / 2) {
                return true;
            }
        }
        return false;
    }

}
