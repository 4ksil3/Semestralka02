/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fri.zavrsanova.semestralka.hrac;

import fri.zavrsanova.semestralka.grafika.Lopta;
import fri.zavrsanova.semestralka.mapa.Smer;
import fri.zavrsanova.semestralka.zoznamPapania.Papanie;
import javax.swing.JOptionPane;

/**
 * Trieda hrac predstavuje Hraca. Zabezpecuje vsetky zmeny stavu, ktore hrac
 * vyzaduje v pripade zjedenia rozneho druhu papania.
 */
public class Hrac {

    private final Lopta lopta;
    private int zivoty;
    private int skore;
    private Smer aktualnySmer;
    private boolean zije;

    public Hrac() {
        this.lopta = new Lopta();
        this.lopta.zobrazLoptu();
        this.zivoty = 2;
        this.skore = 0;
        this.zije = true;
        this.aktualnySmer = Smer.VPRAVO;
    }

    /**
     * Vrati priemer hracovej lopty.
     *
     * @return int priemer
     */
    public int getPriemer() {
        return this.lopta.getPriemer();
    }

    /**
     * Znizi zivot hracovi a v pripade, ze hrac uz nema dalsie zivoty tak zavola
     * metodu zomri.
     */
    public void znizZivot() {
        this.zivoty -= 1;
        if (this.zivoty == 0) {
            this.zomrel();
        }
    }

    /**
     * Hrac zbiera skore za kazde dobre papanie, ktore pozbiera. Prida mu skore
     * podla parametra oKolko.
     *
     * @param oKolko
     */
    public void pridajSkore(int oKolko) {
        this.skore += oKolko;
    }

    /**
     * Hrac strati skore za kazde zle papanie, ktore pozbiera. Odoberie mu skore
     * podla parametra oKolko.
     *
     * @param oKolko
     */
    public void znizSkore(int oKolko) {
        this.skore -= oKolko;
    }

    /**
     * Vrati hodnotu atributu, ktory oznacuje ci hrac zije alebo nie.
     *
     * @return boolean true ak zije, false ak zomrel
     */
    public boolean getZije() {
        return this.zije;
    }

    /**
     * Zabezpecuje pohyb hraca, pri kazdom tiku Triedy Manazer.
     */
    public void pohyb() {
        switch (this.aktualnySmer) {
            case HORE:
//                this.lopta.posunHore();
                this.lopta.pohyb(Smer.HORE);
                break;
            case DOLE:
//                this.lopta.posunDole();
                this.lopta.pohyb(Smer.DOLE);
                break;
            case VLAVO:
//                this.lopta.posunVlavo();
                this.lopta.pohyb(Smer.VLAVO);
                break;
            case VPRAVO:
//                this.lopta.posunVpravo();
                this.lopta.pohyb(Smer.VPRAVO);
                break;
            default:
                System.out.println("Nespravny smer");
        }
    }

    /**
     * Zmeni velkost priemeru hraca podla parametra.
     *
     * @param zmenVelkost zmeni velkost o danu hodnotu
     */
    public void zmenVelkost(int zmenVelkost) {
        this.lopta.zmenVelkost(zmenVelkost);
    }

    /**
     * Zistuje ci nedoslo ku kolíziam s daným papanim.
     *
     * @param papanie
     * @return boolean true ak doslo ku kolizii, false ak nedoslo ku kolizii
     */
    public boolean kolizie(Papanie papanie) {
        return this.lopta.kolizie(papanie);
    }

    /**
     * Zistuje ci sa zmenil smer hraca, ak ano tak ho zmeni ak nie ostava
     * povodny.
     *
     * @param smer udava akym smerom sa hybe hrac
     */
    public void zmenSmer(Smer smer) {
        this.aktualnySmer = smer;
    }

    /**
     * Zmeni smer hraca na opacny. Ak ide hore zmeni sa na dole a podobne.
     */
    public void otocSmer() {
        if (this.aktualnySmer == Smer.DOLE) {
            this.aktualnySmer = Smer.HORE;
        } else if (this.aktualnySmer == Smer.HORE) {
            this.aktualnySmer = Smer.DOLE;
        } else if (this.aktualnySmer == Smer.VPRAVO) {
            this.aktualnySmer = Smer.VLAVO;
        } else if (this.aktualnySmer == Smer.VLAVO) {
            this.aktualnySmer = Smer.VPRAVO;
        }
    }

    /**
     * Zmeni suradnice hraca a presunie ho na spravnu poziciu.
     */
    public void zmenSuradnice() {
        this.lopta.skryLoptu();
        int cislo = this.lopta.getSirkaPlatna() - this.lopta.getSuradnicaX();
        this.lopta.zmenSuradniceX(cislo);
        cislo = this.lopta.getVyskaPlatne() - this.lopta.getSuradnicaY();
        this.lopta.zmenSuradniceY(cislo);
        this.lopta.nastavStred();
        this.lopta.zobrazLoptu();
    }

    /**
     * Ak hrac zje nieco nevhodne alebo sa mu minu zivoty tak sa hodnota
     * atributu this.zije zmeni na false a teda zomrel, vypise sa dosiahnute
     * skore a informacia o ukonceni hry.
     *
     * @return
     */
    public boolean zomrel() {
        this.zije = false;
        JOptionPane.showMessageDialog(null, "Zomrel si! \n Tvoje skore : " + this.skore + "\n Dúfam, že sa vidíme čoskoro! Ahoj");
        System.exit(0);
        return this.zije;
    }

    /**
     * Prida zivot ak narazi na spravne papanie.
     */
    public void pridajZivot() {
        this.zivoty += 1;
    }

    public int getPocetZivotov() {
        return this.zivoty;
    }

    public int getStredX() {
        return this.lopta.getStredLoptyX();
    }

    public int getStredY() {
        return this.lopta.getStredLoptyY();
    }
}
