package fri.zavrsanova.semestralka.aplikacia;

import fri.zavrsanova.semestralka.grafika.Duch;
import fri.zavrsanova.semestralka.grafika.Platno;
import fri.zavrsanova.semestralka.mapa.Smer;
import fri.zavrsanova.semestralka.mapa.Mapa;
import fri.zavrsanova.semestralka.hrac.Hrac;
import fri.zavrsanova.semestralka.hlavneTriedy.TovarenNaPapanie;

/**
 * Trieda Hra sa stará o vytvorenie hlavných tried ako je TovarenNaPapanie,
 * Riadic, Mapa, Manazer a Hrac. Vytvori zaciatocne instancie.
 *
 * @author Eliška Zavrsanova
 */
public class Hra {

    private final Hrac hrac;
    private Duch duch;
    private int tik;
    private final Manazer manazer;
    private final TovarenNaPapanie tovaren;
    private final Mapa mapa;
    private final Riadic riadic;

    public Hra() {
        Platno platno = Platno.dajPlatno();
        this.hrac = new Hrac();
        this.duch = new Duch();
        this.tik = 0;
        this.manazer = new Manazer();
        this.manazer.spravujObjekt(this);
        this.mapa = new Mapa();
        this.tovaren = new TovarenNaPapanie(this.mapa);
        this.tovaren.vytvorZaciatok();
        this.riadic = new Riadic(this.hrac, this.mapa, this.duch);
        this.tovaren.vytvorInstanciuPapania();
    }

    /**
     * Zabezpecuje pohyb hraca dole.
     */
    public void posunDole() {
        this.hrac.zmenSmer(Smer.DOLE);
    }

    /**
     * Zabezpecuje pohyb hraca hore.
     */
    public void posunHore() {
        this.hrac.zmenSmer(Smer.HORE);
    }

    /**
     * Zabezpecuje pohyb hraca vlavo.
     */
    public void posunVlavo() {
        this.hrac.zmenSmer(Smer.VLAVO);
    }

    /**
     * Zabezpecuje pohyb hraca vpravo.
     */
    public void posunVpravo() {
        this.hrac.zmenSmer(Smer.VPRAVO);
    }

    /**
     * Zabezpecuje pri kazdom tiku kontrolu ci hrac zije, ak zije tak uskutocni
     * pohyb a skontroluje kolizie.
     */
    public void tik() {
        this.tik++;
        if (this.hrac.getZije()) {
            if (this.tik > 20) {
                this.duch.pohyb();
                this.riadic.zrazkaSduchom(this.hrac, this.duch);
            }
            this.hrac.pohyb();
            this.riadic.odstranZmapy(this.hrac, this.tovaren);
            if (this.tik % 10 == 0) {
                this.duch.nastavSmer();
            }
        }

    }
}
// TODO: PRIDAT BALICKY
// SKONTROLVOAT CHECKSTYLE
