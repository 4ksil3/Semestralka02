package fri.zavrsanova.semestralka.aplikacia;

import fri.zavrsanova.semestralka.grafika.Duch;
import fri.zavrsanova.semestralka.mapa.Mapa;
import fri.zavrsanova.semestralka.hrac.Hrac;
import java.util.ArrayList;
import fri.zavrsanova.semestralka.hlavneTriedy.TovarenNaPapanie;
import fri.zavrsanova.semestralka.zoznamPapania.Jablcko;
import fri.zavrsanova.semestralka.zoznamPapania.Otrava;
import fri.zavrsanova.semestralka.zoznamPapania.OtraveneJablko;
import fri.zavrsanova.semestralka.zoznamPapania.Papanie;

/**
 *
 * Riadic je jedna z hlavných tried, ktoré zabezpecuju kontrolu kolizii a
 * spravuju papanie v mape.
 */
public class Riadic {

    private final Hrac hrac;
    private final Mapa mapa;
    private Duch duch;  

    public Riadic(Hrac hrac, Mapa mapa, Duch duch) {
        this.mapa = mapa;
        this.hrac = hrac;
        this.duch = duch;
    }

    /**
     * Kontroluje ci sa nestretol hrac s papanim. Ak sa stretli, vymaze papanie
     * z mapy a podla toho ake papanie zjedol sa zmeni hracov stav.
     */
    public void odstranZmapy(Hrac hrac, TovarenNaPapanie tovaren) {
        ArrayList<Papanie> zjedene = new ArrayList<>();
        for (Papanie papanie : this.mapa.getKopiaMapy()) {
            if (hrac.kolizie(papanie)) {
                papanie.zjedz(hrac);
                zjedene.add(papanie);
                papanie.skry();
                tovaren.vytvorInstanciuPapania();

            }
        }
        this.mapa.vymazZmapy(zjedene);
    }
    
    public void zrazkaSduchom(Hrac hrac, Duch duch) {
        if (this.duch.kolizie(this.hrac)) {
            hrac.zomrel();
        }
    }

}
