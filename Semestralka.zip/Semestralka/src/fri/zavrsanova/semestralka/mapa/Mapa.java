/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fri.zavrsanova.semestralka.mapa;

import fri.zavrsanova.semestralka.zoznamPapania.Papanie;
import java.util.ArrayList;

/**
 * Mapa obsahuje vsetky druhy papania, ktore sa mozu vyskytnut na platne, a
 * ktore je mozne zjest, a spravuje ich.
 */
public class Mapa {

    private ArrayList<Papanie> mapa;

    public Mapa() {
        this.mapa = new ArrayList<>();
    }

    /**
     * Po vytvoreni sa papanie z parametra pridá do mapy.
     * @param papanie papanie, ktore sa ma pridat
     */
    public void pridajDoMapy(Papanie papanie) {
        this.mapa.add(papanie);
    }

    /**
     * Vrati velkost mapy.
     * @return int velkost mapy.
     */
    public int getSize() {
        return this.mapa.size();
    }

    /**
     * Ak uz bolo papanie zjedene, vymaze ho z mapy.
     * @param zjedene 
     */
    public void vymazZmapy(ArrayList<Papanie> zjedene) {
        this.mapa.removeAll(zjedene);
    }

    /**
     * Vrati kopiu mapy ???????
     * @return 
     */
    public ArrayList<Papanie> getKopiaMapy() {
        return new ArrayList<>(this.mapa);
    }

}
